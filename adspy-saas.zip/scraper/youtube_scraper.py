from scraper.base_scraper import BaseScraper

class YouTubeScraper(BaseScraper):
    def run(self):
        results = []
        # placeholder: implement youtube scraping
        return results
