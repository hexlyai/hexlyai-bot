from scraper.base_scraper import BaseScraper

class TikTokScraper(BaseScraper):
    def run(self):
        results = []
        # placeholder: implement playwright scraping
        return results
