# AdSpy SaaS Telegram Bot

### How to setup
1. Create Telegram bot via @BotFather, copy token
2. Create Supabase project & tables: users, ads
3. Add Lemon Squeezy webhook URL
4. Fill .env file with all secrets
5. Upload repo to GitHub
6. Deploy to Northflank or Render
7. Run scraper_runner.py periodically to update ads
8. Paid users can use /latest command in bot
